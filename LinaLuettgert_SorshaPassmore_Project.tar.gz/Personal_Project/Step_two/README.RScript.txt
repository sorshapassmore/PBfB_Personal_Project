## README- Creating png files in R

The folder Step_two contains: 
-Data: "Out_Oregon.csv" (contains water temperature and chlorophyll data 
	for the gulf of mexico from 1994-2008)
-Scripts: R-script "projectGIF.R" (creates pngs)
-Results: Contains created pngs for every year for temperature and chlorophyll

---HOW TO RUN---
The working directory in the R script must be changed to the path where the 
	csv file "Out_Oregon.csv" is located.
The R code can be run in the terminal using:
Rscript ~/Personal_Project/Scripts/projectGIF.R
	#change if the path of the R script differs

---General information on the R script---
This R script takes the csv file "Out_Oregon.csv" as input, which was created
in the previous step using python. The file contains water temperature and
chlorophyll data for several coordinates in the gulf of mexico from 1994-2008.
The script will interpolate values for temperature/chlorophyll for the area
where the data was takes from (upper west part of the gulf of mexico),
so the area can be coloured later on a map depending on the values.
The script will create png pictures for both water temperature and chlorophyll
concentration for every year. 
These pngs will later be used for creating GIFs 

The script does the following tasks:
-load packages for interpolation, creating maps and saving png files 
-read in the csv file and create a subset with needed data
-run a for loop for each year for temperature: 
	-create subset
	-interpolate
	-open png file
	-map interpolation
	-add map of area and data points
	-save png 
-run a for loop for each year for chlorophyll concentration:
	-takes the same steps as for temperature

The pngs will be saved in the same directory where the csv file "Out_Oregon.csv"
is located (the working directory you set in R)