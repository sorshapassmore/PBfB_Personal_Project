#This R script takes a csv file which contains water temperature and chlorophyll data
#for several coordinates in the gulf of mexico from 1994-2008
#and creates png pictures for every variable for each year 
#These pngs will later be used for creating GIFs 

#load packages
library(maps)
library(mapdata)
library(fields)
library(png)

setwd("/home/sorsha/Personal_Project/Step_two/Data") #put your working directory here
datafile <- "Out_Oregon.csv" #datafile you want to import
gulfall<-read.csv(datafile,sep="\t") #import
#create a subset, only containing measurements in depth 5m and exclude years 2001-2003 as they contain incorrect data
#only include coordinates, year, temperature and chlorophyll concentrations
gulfall <- subset(gulfall, Depth==5 & Year!=2001 & Year!=2002 & Year!=2003, select=c(Latitude,Longitude,Year,Temperature,Chlorophyll))
summary(gulfall) #check for minimum maximum coordinates and temperature/chlorophyll levels 

#create a list of years to loop through 
list.Year <- unique(gulfall$Year)
length(list.Year)
#set x and y coordinate ranges already now so they are the same for all graphs
xlim <- c(min(gulfall$Longitude)-0.5, max(gulfall$Longitude)+0.5) #ranges taken from summary(gulfall)
ylim <- c(min(gulfall$Latitude)-1, max(gulfall$Latitude)+1)
year<-2000

#### Temperature  ####
#loop through every year
 for (year in c(list.Year)){
    #print(year)
   #create subset hich contains Temperature and coordinates for current year
    gulftemp <- subset(gulfall, Year == year ,select=c(Year, Latitude,Longitude,Temperature))
   #create variables for the Tps function
    x <- cbind(gulftemp$Longitude, gulftemp$Latitude) #coordinates
    y <- gulftemp$Temperature #temperature (dependent variable)
   #interpolate using the Tps function
    fit<- Tps(x,y, lambda=0) 
   #creating images
    OutputName <- paste("mapTemp_",year, ".png", sep="") #set outputname
    png(OutputName,height=700,width=1000) #open new png and set size
    par(cex.main=3) #setting title size now (does not work inside the surface function)
    #plotting the interpolated data using the surface function
    #zlim sets temperature range so its the same for all years (range taken from summary(gulfall))
    surface(fit, xlim=xlim, ylim=ylim, zlim = c(21.5,31.5), xlab= "Longitude", ylab="Latitude", 
            main= paste("Water temperature [°C]", year, sep="  "))
    #put a map of the area on top; add=TRUE puts it on top instead of creating a new graph
    map('worldHires', add=TRUE, fill=TRUE, col='white', boundary='black', xlim=xlim, ylim=ylim, lwd = 2)
    points(gulftemp$Longitude, gulftemp$Latitude,cex=0.5,col="black") #add actual data points
    dev.off() #save png
 }

#### Chlorophyll ####
#loop through every year, very similar to the temperature loop
for (year in c(list.Year)){
    #print(year)
   #create subset hich contains chlorophyll and coordinates for current year  
    gulfchl <- subset(gulfall, Year == year ,select=c(Year, Latitude,Longitude,Chlorophyll))
   #create variables for the Tps function
    x <- cbind(gulfchl$Longitude, gulfchl$Latitude) #coordinates
    y <- gulfchl$Chlorophyll #chlorophyll (dependent variable)
   #interpolate using the Tps function
    fit<- Tps(x,y, lambda=0) # use the tps function to fit the impacts
   #creating images
    OutputName <- paste("mapChl_",year, ".png", sep="") #set outputname
    png(OutputName,height=700,width=1000) #open new png and set size
    par(cex.main=3) #setting title size now (does not work inside the surface function)
    #plotting the interpolated data using the surface function
    #zlim sets chlorophyll range so its the same for all years (range taken from summary(gulfall))
    surface(fit, xlim=xlim, ylim=ylim, zlim = c(0,45), xlab= "Longitude", ylab="Latitude", 
          main= paste("Chlorophyll concentration [ug/l]", year, sep="  "))
    #put a map of the area on top; add=TRUE puts it on top instead of creating a new graph
    map('worldHires', add=TRUE, fill=TRUE, col='white', boundary='black', xlim=xlim, ylim=ylim, lwd = 2)
    points(gulftemp$Longitude, gulftemp$Latitude,cex=0.5,col="black")
    dev.off()#save png
}