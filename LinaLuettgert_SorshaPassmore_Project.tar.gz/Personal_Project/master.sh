#!/bin/bash
# This master shell script will allow the user to run in full our program
# that we created in order to reformat NOAA databases with python, create
# coloured maps with sample points and interpolation, and finally 
# creating a gif to visualise the data efficiently

### Before using this script, the user access permissions must be ###
### modified so this script can be executed. Please type on Terminal ###

# chmod u+x master.sh

# Now you should as the user be able to access this script
# Change working directory 'cd' to where you would like the new file to be 
# created. The new file will be the output of the old original data file so we
# kept it within the same directory. In this case we wanted both the files to 
# be within the ~/Personal_Project/Step_one/Data directory.

cd ~/Personal_Project/Step_one/Code

# You can type ls to make sure you are in the correct directory and to check 
# your data file is indeed there. 

# Once in the desired working directory, we will need to also change access
# permissions of the python script 'Project_Python.py' will need to be made
# executable. Repeat the chmod command as earlier, with the different file name.

chmod u+x project_python.py

# Now it is time to run the python script as seen in Step one. Once you have 
# added the script to nano and saved the script as 'Project_Python' then you can
# move on to the next step. 

#Go to path where Oregon file is
cd ~/Personal_Project/Step_one/Data

~/Personal_Project/Step_one/Code/project_python.py

# Will run Project_Python in the current directory. It will use the input file
# to create an output file: 'Out_Oregon2.CTD.csv'

# Now we move on to step 2
# Please type the following command to run the Rstudio script from the terminal

#change working directory inside R to where the csv file is 'Out_Oregon'

Rscript ~/Personal_Project/Step_two/Code/projectGIF.R

#The R script will run and create the new maps
#Finally, to create the GIFs, run the following command in terminal

#Go to folders where the pictures are
cd ~/Personal_Project/Step_three/Data

convert -delay 100 mapTemp*.png -loop 5 binomTemp.gif
convert -delay 100 mapChl*.png -loop 5 binomChlr.gif

#used the MagickImage to create GIFs, make sure you have installed all of the 
# required packages.