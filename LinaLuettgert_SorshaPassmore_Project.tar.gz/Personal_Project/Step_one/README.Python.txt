## README- Reformatting csv file

The folder Step_one contains: 
-Data: "Oregon.csv" (contains information on the cruises taken in the 
	gulf of mexico from 1994-2008, including chlorophyll and water temperature data
-Scripts: "project_python.py" (creates new csv file with only desired content
-Results: "Out_Oregon.csv", the new csv file

---HOW TO RUN---
The python code must be given permission to run first:
In the terminal type: 
cd ~/Personal_Project/Step_one/Scripts
#change if your path for "project_python.py" differs
chmod u+x project_python.py

Then change your working directory to the path where the csv file "Oregon.csv" is placed.
cd ~/Personal_Project/Step_one/Data
#change if your path differs

The script can then be run in the terminal using:
project_python.py

---General information on the Python script---
The program takes a csv file downloaded from NOAA which contains water
temperature and chlorophyll values for several data points and writes a new
file which only contains the following values: latitude, longitude, year,
month, day, depth, water temperature and chlorophyll concentration.

The script does the following tasks:
-import read module
-set filenames 
-give permissions to write output and open both input and output file
-setting search(regular expression terms and the replacements
-run a for loop which runs through the csv line by line, picks out 
	desired information and creates a new csv file containing these informations
-close the files
-give some output for the user