#! /usr/bin/env python
#Project Python:Sorsha Passmore & Lina Luettgert

#This program takes a csv file downloaded from NOAA which contains water
#temperature and chlorophyll values for several data points and writes a new
#file which only contains the following values: latitude, longitude, year,
#month, day, depth, water temperature and chlorophyll concentration

print "This program takes a csv file downloaded from NOAA which contains\
 water temperature and chlorophyll values for several data points and writes\
 a new file which only contains the following values: latitude, longitude,\
 year, month, day, depth, water temperature and chlorophyll concentration."

import re #read module for regular expressions into the program

#Define names of input and output file (in new variables):
InFileName="Oregon.csv"
OutFileName="Out_"+InFileName #derive from input file name

#give permission to write output for later:
WriteOutFile=True #if not desired set as False

InFile=open(InFileName,'r') #open the input file (read modus)

#define header for new table(output);separated by tabs:
HeaderLine='Latitude\tLongitude\tYear\tMonth\tDay\tDepth\tTemperature\tChlorophyll'

if WriteOutFile: #if permission given above, do:
	OutFile=open(OutFileName, 'w') #create output file (can be written into)
	OutFile.write(HeaderLine+'\n') #add header to new output file (and put end-of-line after it)

#Now we define the regular expressions/search terms and replacements 
#(what we want to save) for all the variables we need in our new file: 
#Latitude, longitude, year, month, day, depth, temperature and chlorophyll

SearchLat='Latitude'
RepLat='([\d\.\-]+)' #save values (same for the others)
SearchLong='Longitude'
RepLong='([\d\.\-]+)'
SearchY='Year'
RepY='([\d\.]+)'
SearchM='Month'
RepM='([\d\.]+)'
SearchD='Day'
RepD='([\d\.]+)'
SearchDTC=r'^\s+\d+,\s+([\d.]+),\d+[^\d]+([\d.]+),\d+[^\d]+[\d.]+,\d+[^\d]+[\d.]+,\d+[^\d]+([\d.]+).+\s' #table rows
RepDTC1=r'\1' #keep depth #r for regular expressions
RepDTC2=r'\2' #keep temperature
RepDTC3=r'\3' #keep chlorophyll

rows=0 #set variable for counting number of rows (data points) in our new file

for Line in InFile: #go through every line of the file and do for each:
	if re.search(SearchLat,Line): #if line contains the word latitude:
		Lat=re.search(RepLat,Line) #search for latitude values (always in the same line)
		Lat=Lat.group(1) #save them
		#print Lat
		rows=rows+1 #add 1 (new latitude line=new data point=new row in output file)
	#if line does not contain the word latitude:
	elif re.search(SearchLong,Line): #if line contains the word longitude:
		Long=re.search(RepLong,Line) #search for longitude values
		Long=Long.group(1) #save them
		#print Long
	elif re.search(SearchY,Line):#...
		Year=re.search(RepY,Line)
		Year=Year.group(1)
		#print Year
	elif re.search(SearchM,Line):
		Month=re.search(RepM,Line)
		Month=Month.group(1)
		#print Month
	elif re.search(SearchD,Line):
		Day=re.search(RepD,Line)
		Day=Day.group(1)
		#print Day
	#if line matches with regular expression for depth, temperature and chlorophyll:
	elif re.search(SearchDTC, Line):
		Depth=re.sub(SearchDTC,RepDTC1,Line) #replace with depth values
		Temp=re.sub(SearchDTC,RepDTC2,Line) #replace with temperature values
		Chl=re.sub(SearchDTC,RepDTC3,Line) #replace with chlorophyll values
		#print Depth, Temp, Chl
		#As the DTC rows are always at the end of each data point entry,
		#we will create a variable now which contains all desired values for each data point
		#this way we create a row for each data point (separated by tabs)
		row=Lat+"\t"+Long+"\t"+Year+"\t"+Month+"\t"+Day+"\t"+Depth+"\t"+Temp+"\t"+Chl
		#print row
		if WriteOutFile: #if permission given
			OutFile.write(row+'\n') #add row to the output file
		else: print row

#Close the files and give some information for the user
InFile.close()
if WriteOutFile:
	OutFile.close()
	print "\nThe new file", OutFileName,"contains",rows, "data points."
else:
	print "There was no file created"